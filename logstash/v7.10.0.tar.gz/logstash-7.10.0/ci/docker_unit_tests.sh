#!/bin/bash
ci/docker_run.sh logstash-unit-tests ci/unit_tests.sh $@
