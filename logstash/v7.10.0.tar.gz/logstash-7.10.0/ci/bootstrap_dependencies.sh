#!/bin/bash

./gradlew installDefaultGems
