This is not a real working module, i.e. one that will work in kibana.
